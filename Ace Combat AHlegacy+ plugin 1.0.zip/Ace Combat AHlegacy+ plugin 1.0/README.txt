=============================================
#	Generated with Gateshark2NTR	    #
=============================================

=============================================
#	  How to use this plugin	    #
=============================================
1- Press [Select] to shows up the menu
--> You can navigate in the menu with the DPAD Key UP and DOWN
--> Press A to activate / de-activate a cheat
--> Press B to exit the menu and return to the game
--> You can change the hotkey for showing up the menu by pressing [Start] in the menu
--> You can adjust the speed of the cheats execution by pressing [Select] in the menu
Tip:
-- You can easily navigate in a spoiler with those keys:
   --> DPAD Key Left: Go back to the upper line of the spoiler
   --> DPAD Key Right: Go to the last line of the spoiler

=============================================
#	Cheats available in this plugin	    #
=============================================
- Infinite cash
